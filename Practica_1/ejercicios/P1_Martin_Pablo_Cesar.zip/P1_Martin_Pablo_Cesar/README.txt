
Autores:
  Cesar Ramirez Martinez
  Martin Sanchez Signorini
  Pablo Ruiz Revilla

Instrucciones de ejecucion:
  1) Ejecutar el comando "make all"
  2) Para cada ejemplo ejecutar el comando "./eji" (siendo 1 <= i <= 7)
  3) Ejecutar el comando "make clean"
